package com.my.shopee.myshopee.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.my.shopee.myshopee.R;

public class TermsAndConditionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_and_conditions);
    }
}
